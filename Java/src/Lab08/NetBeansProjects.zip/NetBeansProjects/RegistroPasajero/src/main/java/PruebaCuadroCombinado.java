
import Actividades.Actividad1.MarcoCuadroCombinado;
import javax.swing.JFrame;

public class PruebaCuadroCombinado {

    public static void main(String[] args) {
        MarcoCuadroCombinado marcoCuadroCombinado = new MarcoCuadroCombinado();
        marcoCuadroCombinado.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marcoCuadroCombinado.setSize(350, 250);
        marcoCuadroCombinado.setVisible(true);
    }
} // fin de la clase PruebaCuadroCombinado

