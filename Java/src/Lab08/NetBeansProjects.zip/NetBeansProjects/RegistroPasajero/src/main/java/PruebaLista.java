
import javax.swing.JFrame;
import Actividades.Actividad1.MarcoLista;

public class PruebaLista {
    public static void main(String[] args) {
        MarcoLista marcoLista = new MarcoLista();
        // crea objeto MarcoLista
        marcoLista.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marcoLista.setSize(350, 150);
        marcoLista.setVisible(true);
    }
} // fin de la clase PruebaLista
