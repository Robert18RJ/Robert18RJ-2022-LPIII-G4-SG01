/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.registropasajero;

/**
 *
 * @author 51948
 */
public class RegistroPasajero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Registro_Pasajero RegistroPasajero = new Registro_Pasajero();
        RegistroPasajero.setVisible(true);

    }

}
